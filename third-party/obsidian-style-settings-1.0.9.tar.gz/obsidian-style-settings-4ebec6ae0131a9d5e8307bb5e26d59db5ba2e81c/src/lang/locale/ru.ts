export const ru = {};
